<?php
include('includes/header.php');
?>

<main class="container">
    <h2>🌾 Live Mandi Rates in India</h2>
    <p>Below are current sample prices of selected crops in various states.</p>

    <table>
        <thead>
            <tr>
                <th>Commodity</th>
                <th>State</th>
                <th>Market</th>
                <th>Modal Price (₹/quintal)</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Sample Data - You can later replace this with an API fetch
            $rates = [
                ['Wheat', 'Punjab', 'Ludhiana', 2120, '2025-06-05'],
                ['Rice', 'West Bengal', 'Kolkata', 1860, '2025-06-05'],
                ['Onion', 'Maharashtra', 'Nashik', 1280, '2025-06-05'],
                ['Tomato', 'Karnataka', 'Bangalore', 920, '2025-06-05'],
                ['Sugarcane', 'Uttar Pradesh', 'Meerut', 340, '2025-06-05'],
            ];

            foreach ($rates as $rate) {
                echo "<tr>
                        <td>{$rate[0]}</td>
                        <td>{$rate[1]}</td>
                        <td>{$rate[2]}</td>
                        <td>₹{$rate[3]}</td>
                        <td>{$rate[4]}</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
</main>

<style>
.container {
    padding: 20px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
table, th, td {
    border: 1px solid #ccc;
}
th, td {
    padding: 12px;
    text-align: center;
}
th {
    background-color: #f2f2f2;
}
</style>

<?php include('includes/footer.php'); ?>
