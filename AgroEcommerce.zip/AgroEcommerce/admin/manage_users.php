<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

// ✅ Only allow specific admin access
$admin_email = 'sheikhirafanrashid@gmail.com';

if (!isset($_SESSION['user_id']) || $_SESSION['user_email'] !== $admin_email) {
    echo "<p>Access denied. Only admin can access this page.</p>";
    include('../includes/footer.php');
    exit();
}

// ✅ Handle Delete Request
$message = '';
if (isset($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);

    // Prevent self-deletion
    if ($delete_id == $_SESSION['user_id']) {
        $message = "❌ You cannot delete your own admin account.";
    } else {
        $conn->query("DELETE FROM users WHERE id = $delete_id");
        $message = "✅ User deleted successfully.";
    }
}

// ✅ Fetch Users
$result = $conn->query("SELECT id, name, email, user_type FROM users ORDER BY user_type, name");
?>

<main class="container">
    <h2>👥 Manage Users</h2>
    <?php if ($message): ?>
        <div class="alert"><?= $message ?></div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>User Type</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id']; ?></td>
                <td><?= htmlspecialchars($row['name']); ?></td>
                <td><?= htmlspecialchars($row['email']); ?></td>
                <td><?= ucfirst($row['user_type']); ?></td>
                <td>
                    <?php if ($row['email'] !== $admin_email): ?>
                        <a href="?delete=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this user?')">❌ Delete</a>
                    <?php else: ?>
                        <span style="color: #888;">—</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</main>

<style>
.container {
    padding: 20px;
    max-width: 900px;
    margin: auto;
}
.alert {
    background-color: #e1f5e1;
    color: #2e7d32;
    padding: 10px;
    border: 1px solid #c8e6c9;
    margin-bottom: 15px;
    text-align: center;
    border-radius: 5px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    background: white;
}
th, td {
    padding: 12px;
    text-align: center;
    border: 1px solid #ddd;
}
th {
    background-color: #f2f2f2;
}
@media (max-width: 600px) {
    table, thead, tbody, th, td, tr {
        display: block;
    }
    thead tr {
        display: none;
    }
    td {
        position: relative;
        padding-left: 50%;
        text-align: left;
    }
    td::before {
        position: absolute;
        left: 10px;
        width: 45%;
        white-space: nowrap;
        font-weight: bold;
    }
    td:nth-child(1)::before { content: "ID"; }
    td:nth-child(2)::before { content: "Name"; }
    td:nth-child(3)::before { content: "Email"; }
    td:nth-child(4)::before { content: "User Type"; }
    td:nth-child(5)::before { content: "Action"; }
}
</style>

<?php include('../includes/footer.php'); ?>
