<?php
session_start();
include('includes/db.php');
include('includes/header.php');


if (!isset($_SESSION['user_id'])) {
    echo "<p>Please <a href='pages/login.php'>login</a> to access your profile.</p>";
    include('includes/footer.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Fetch current user data
$query = $conn->prepare("SELECT * FROM users WHERE id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = htmlspecialchars($_POST['name']);
    $email   = htmlspecialchars($_POST['email']);
    $phone   = htmlspecialchars($_POST['phone']);
    $address = htmlspecialchars($_POST['address']);

    $update = $conn->prepare("UPDATE users SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?");
    $update->bind_param("ssssi", $name, $email, $phone, $address, $user_id);
    
    if ($update->execute()) {
        $message = "✅ Profile updated successfully.";
        // Refresh data
        $query->execute();
        $result = $query->get_result();
        $user = $result->fetch_assoc();
    } else {
        $message = "❌ Error updating profile. Try again.";
    }
}
?>

<main class="container">
    <h2>🙍‍♂️ My Profile</h2>

    <?php if ($message): ?>
        <p style="color: <?= strpos($message, '✅') !== false ? 'green' : 'red'; ?>"><?= $message; ?></p>
    <?php endif; ?>

    <form method="POST" class="profile-form">
        <label>Name:</label>
        <input type="text" name="name" required value="<?= htmlspecialchars($user['name']); ?>">

        <label>Email:</label>
        <input type="email" name="email" required value="<?= htmlspecialchars($user['email']); ?>">

        <label>Phone:</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']); ?>">

        <label>Address:</label>
        <textarea name="address" rows="3"><?= htmlspecialchars($user['address']); ?></textarea>

        <button type="submit">Update Profile</button>
    </form>
</main>

<style>
.container {
    padding: 20px;
    max-width: 500px;
    margin: auto;
    background: #f9f9f9;
    border-radius: 10px;
}
.profile-form {
    display: flex;
    flex-direction: column;
}
.profile-form label {
    margin-top: 10px;
    font-weight: bold;
}
.profile-form input, .profile-form textarea {
    padding: 8px;
    margin-top: 5px;
    border-radius: 6px;
    border: 1px solid #ccc;
}
.profile-form button {
    margin-top: 15px;
    padding: 10px;
    background: #28a745;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
.profile-form button:hover {
    background: #218838;
}
</style>

<?php include('includes/footer.php'); ?>
