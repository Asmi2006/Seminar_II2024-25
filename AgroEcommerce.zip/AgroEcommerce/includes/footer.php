<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<footer class="site-footer">
    <style>
        .site-footer {
            background-color: #153f1a;
            color: white;
            padding: 40px 20px 10px;
            font-family: sans-serif;
        }

        .footer-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        a {
            text-decoration: none;
        }


        .footer-section h4 {
            font-size: 18px;
            margin-bottom: 10px;
            border-bottom: 1px solid white;
            padding-bottom: 5px;
        }

        .footer-section p {
            font-size: 14px;
        }

        .footer-section ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-section ul li {
            margin-bottom: 8px;
        }

        .footer-section ul li a {
            color: white;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s ease;
        }

        .footer-section ul li a:hover {
            color: #ffcc00;
        }

        .footer-bottom {
            text-align: center;
            padding: 15px 0 0;
            font-size: 13px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            margin-top: 30px;
        }
    
    </style>

    <div class="footer-container">
        <div class="footer-section">
            <h4>AgroTrade</h4>
            <p>Connecting farmers and buyers across India with trust and technology.</p>
        </div>

        <div class="footer-section">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="/AgroEcommerce/pages/home.php">Home</a></li>
                <li><a href="/AgroEcommerce/pages/about.php">About Us</a></li>
                <li><a href="/AgroEcommerce/pages/services.php">Services</a></li>
                <li><a href="/AgroEcommerce/pages/contact.php">Contact</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h4>Information</h4>
            <ul id="info-links">
                <li><a href="/AgroEcommerce/pages/product_certification.php" class="Link">Product Certification</a></li>
                <li> <a href="/AgroEcommerce/pages/transport_delivery.php" class="Link">Transport & Delivery</a></li>
                <li> <a href="/AgroEcommerce/pages/privacy_policy.php" class="Link">Privacy Policy</a>  </li>
                <li><a href="/AgroEcommerce/pages/terms_conditions.php" class="Link">Terms & Conditions</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h4>Support</h4>
            <ul>
                <li><a href="#">FAQs</a></li>
                <li><a href="#">Customer Support</a></li>
                <li><a href="#">Feedback</a></li>
                <li><a href="#">Report a Problem</a></li>
            </ul>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; <?php echo date("Y"); ?> AgroTrade. All rights reserved.</p>
    </div>

    <!-- JS Scripts -->
    <script src="/AgroEcommerce/assets/js/cart.js"></script>
    <script src="/AgroEcommerce/assets/js/preview.js"></script>
    <script src="/AgroEcommerce/assets/js/navbar.js"></script>
</footer>

</body>

</html>