<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

if (!isset($_GET['id'])) {
    echo "<p>Product not found.</p>";
    include('../includes/footer.php');
    exit();
}

$product_id = intval($_GET['id']);
$product = null;

// Fetch product
$sql = "SELECT p.*, u.name as farmer_name 
        FROM products p
        JOIN users u ON p.farmer_id = u.id
        WHERE p.id = $product_id";
$result = $conn->query($sql);
if ($result->num_rows == 1) {
    $product = $result->fetch_assoc();
} else {
    echo "<p>Product not found.</p>";
    include('../includes/footer.php');
    exit();
}

// Handle add to cart
$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
        $message = "Please <a href='login.php'>login as a buyer</a> to add to cart.";
    } else {
        $user_id = $_SESSION['user_id'];
        $quantity = intval($_POST['quantity']);

        $sql = "INSERT INTO cart (user_id, product_id, quantity)
                VALUES ($user_id, $product_id, $quantity)";
        if ($conn->query($sql)) {
            $message = "Product added to cart!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}
?>

<main class="container">
    <h2><?php echo htmlspecialchars($product['title']); ?></h2>
    <div class="product-detail">
        <img src="/AgroEcommerce/uploads/<?php echo $product['image']; ?>" alt="">
        <div>
            <p><strong>Price:</strong> ₹<?php echo $product['price']; ?></p>
            <p><strong>Farmer:</strong> <?php echo $product['farmer_name']; ?></p>
            <p><?php echo $product['description']; ?></p>

            <?php if ($message) echo "<p class='message'>$message</p>"; ?>

            <form method="POST">
                <label>Kg:</label>
                <input type="number" name="quantity" value="1" min="1">
                <button type="submit">Add to Cart</button>
            </form>
        </div>
    </div>
</main>

<style>
.product-detail {
    display: flex;
    flex-direction: column;
    gap: 20px;
}
.product-detail img {
    max-width: 300px;
    object-fit: cover;
}
@media(min-width: 768px) {
    .product-detail {
        flex-direction: row;
    }
}
.message {
    margin-top: 10px;
    color: green;
}
</style>

<?php include('../includes/footer.php'); ?>
