<?php include('../includes/header.php'); ?>
<main class="container">
    <h2>Transport & Delivery</h2>
    <p>We use India’s vast logistics and transport network to deliver agricultural products safely and on time. Our delivery options include:</p>
    <ul>
        <li><strong>Courier Services:</strong> For small parcels via India Post, Delhivery, etc.</li>
        <li><strong>Cold Chain:</strong> For perishable items like fruits & vegetables.</li>
        <li><strong>Local Transport:</strong> Tie-ups with local transporters for bulk orders.</li>
    </ul>
    <p>Estimated delivery time is 2–7 working days depending on location. Tracking is provided after dispatch.</p>
</main>

<style>
.container {
    max-width: 900px;
    margin: auto;
    padding: 20px;
    font-family: Arial, sans-serif;
}
</style>
<?php include('../includes/footer.php'); ?>
