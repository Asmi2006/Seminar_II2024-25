<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Only needed if you plan to re-send OTP from here (not used in current code)
require '../vendor/autoload.php';
session_start();
include('../includes/db.php');

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $enteredOtp = trim($_POST['otp']);

    $stmt = $conn->prepare("SELECT otp FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($dbOtp);
    
    if ($stmt->fetch()) {
        $stmt->close();

        if ($enteredOtp === $dbOtp) {
            // ✅ Mark as verified
            $updateStmt = $conn->prepare("UPDATE users SET is_verified = 1 WHERE email = ?");
            $updateStmt->bind_param("s", $email);
            $updateStmt->execute();
            $updateStmt->close();

            $message = "✅ Email verified successfully! You can now <a href='login.php'>login</a>.";
        } else {
            $message = "❌ Incorrect OTP. Please try again.";
        }
    } else {
        $message = "❌ Email not found. Please enter the registered email.";
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>OTP Verification</title>
    <style>
        .container {
            max-width: 500px;
            margin: 40px auto;
            padding: 20px;
            border: 2px solid #aaa;
            border-radius: 10px;
            background-color: #f9f9f9;
            font-family: sans-serif;
        }

        h2 {
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"], input[type="email"] {
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #aaa;
            border-radius: 5px;
        }

        button {
            background-color: green;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .message {
            color: red;
            text-align: center;
            font-weight: bold;
        }

        .message a {
            color: green;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Verify Your Email</h2>
        <?php if ($message) echo "<p class='message'>$message</p>"; ?>

        <form method="POST">
            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Enter OTP:</label>
            <input type="text" name="otp" required>

            <button type="submit">Verify</button>
        </form>
    </div>
</body>
</html>
