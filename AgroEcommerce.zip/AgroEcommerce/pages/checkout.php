<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    echo "<p>Please <a href='login.php'>login as a buyer</a> to checkout.</p>";
    include('../includes/footer.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get registered address
$user_result = $conn->query("SELECT address FROM users WHERE id = $user_id");
$user_data = $user_result->fetch_assoc();
$registered_address = $user_data['address'];

// Initial fetch of cart
$sql = "SELECT c.id as cart_id, p.id as product_id, p.title, p.price, c.quantity
        FROM cart c
        JOIN products p ON c.product_id = p.id
        WHERE c.user_id = $user_id";
$cart_items = $conn->query($sql);

if ($cart_items->num_rows == 0) {
    echo "<p>Your cart is empty. <a href='product_list.php'>Browse Products</a></p>";
    include('../includes/footer.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address_choice = $_POST['address_choice'];
    $final_address = ($address_choice === 'new') ? $conn->real_escape_string($_POST['new_address']) : $registered_address;

    $conn->begin_transaction();

    try {
        // Re-fetch cart
        $cart_items = $conn->query($sql);

        // Calculate total
        $total = 0;
        while ($item = $cart_items->fetch_assoc()) {
            $total += $item['price'] * $item['quantity'];
        }

        // Insert order
        $conn->query("INSERT INTO orders (user_id, total_amount, address) VALUES ($user_id, $total, '$final_address')");
        $order_id = $conn->insert_id;

        // Insert order items
        $cart_items->data_seek(0);
        while ($item = $cart_items->fetch_assoc()) {
            $conn->query("INSERT INTO order_items (order_id, product_id, quantity, price)
                          VALUES ($order_id, {$item['product_id']}, {$item['quantity']}, {$item['price']})");
        }

        // Clear cart
        $conn->query("DELETE FROM cart WHERE user_id = $user_id");

        $conn->commit();
        echo "<p>✅ Order placed successfully! <a href='my_orders.php'>View Orders</a></p>";
        include('../includes/footer.php');
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        echo "<p>❌ Order failed. Try again later.</p>";
        include('../includes/footer.php');
        exit();
    }
}

// Re-fetch cart for display
$cart_items = $conn->query($sql);
?>

<main class="checkout-container">
    <h2>🛒 Checkout</h2>
    <p class="info-text">You're about to place an order with the following items:</p>

    <form method="POST" class="checkout-form">
        <ul class="item-list">
            <?php
            $cart_items->data_seek(0);
            $total = 0;
            while ($item = $cart_items->fetch_assoc()):
                $subtotal = $item['price'] * $item['quantity'];
                $total += $subtotal;
            ?>
            <li class="item">
                <span class="title"><?= htmlspecialchars($item['title']); ?></span>
                <span class="qty">Qty: <?= $item['quantity']; ?></span>
                <span class="price">₹<?= number_format($subtotal, 2); ?></span>
            </li>
            <?php endwhile; ?>
        </ul>

        <div class="total-section">
            <strong>Total:</strong> ₹<?= number_format($total, 2); ?>
        </div>

        <h3>📦 Shipping Address</h3>

        <div class="address-options">
            <label>
                <input type="radio" name="address_choice" value="registered" checked>
                Use registered address:
            </label>
            <p class="registered-address"><?= nl2br(htmlspecialchars($registered_address)); ?></p>

            <label>
                <input type="radio" name="address_choice" value="new">
                Enter new address:
            </label>
            <textarea name="new_address" rows="3" placeholder="Enter new shipping address..."></textarea>
        </div>

        <button type="submit" class="submit-btn">✅ Place Order</button>
    </form>
</main>

<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background: #f8f9fa;
    margin: 0;
    padding: 0;
}

.checkout-container {
    max-width: 700px;
    margin: 30px auto;
    background: #fff;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.checkout-container h2 {
    text-align: center;
    color: #2c3e50;
    margin-bottom: 20px;
}

.info-text {
    font-size: 15px;
    color: #555;
}

.item-list {
    list-style: none;
    padding: 0;
    margin-bottom: 20px;
}

.item {
    display: flex;
    justify-content: space-between;
    border-bottom: 1px solid #ddd;
    padding: 10px 0;
    font-size: 15px;
}

.total-section {
    margin: 20px 0;
    font-size: 18px;
    font-weight: bold;
    color: #1d3557;
}

.address-options {
    margin-bottom: 20px;
}

.address-options label {
    font-weight: bold;
    display: block;
    margin-top: 15px;
}

.registered-address {
    background: #f0f0f0;
    padding: 10px;
    border-radius: 5px;
    margin-left: 20px;
    white-space: pre-line;
}

textarea {
    width: 100%;
    padding: 10px;
    border-radius: 6px;
    border: 1px solid #ccc;
    margin-top: 10px;
    resize: vertical;
    font-family: inherit;
}

.submit-btn {
    background: #28a745;
    color: white;
    padding: 12px 25px;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
    width: 100%;
    margin-top: 20px;
    transition: background 0.3s ease;
}

.submit-btn:hover {
    background: #218838;
}

/* Responsive */
@media (max-width: 600px) {
    .item {
        flex-direction: column;
        align-items: flex-start;
    }

    .item span {
        margin-bottom: 5px;
    }

    .total-section {
        text-align: left;
    }

    .submit-btn {
        font-size: 15px;
    }
}
</style>

<?php include('../includes/footer.php'); ?>
