<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    echo "<p>Please <a href='login.php'>login as a buyer</a> to view your orders.</p>";
    include('../includes/footer.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get orders
$sql = "SELECT * FROM orders WHERE user_id = $user_id ORDER BY order_date DESC";
$orders = $conn->query($sql);
?>

<main class="container">
    <h2>📦 My Orders</h2>

    <?php if ($orders->num_rows == 0): ?>
        <p>You haven't placed any orders yet.</p>
    <?php else: ?>
        <?php while ($order = $orders->fetch_assoc()): 
            $order_id = $order['id'];
            $status = $order['status'];
            $total = $order['total_amount'];
            $date = $order['order_date'];

            // Get order items
            $items = $conn->query("SELECT oi.quantity, oi.price, p.title 
                                   FROM order_items oi
                                   JOIN products p ON oi.product_id = p.id
                                   WHERE oi.order_id = $order_id");
        ?>
            <div class="order-card">
                <h3>Order #<?php echo $order_id; ?> - ₹<?php echo number_format($total, 2); ?></h3>
                <p><strong>Status:</strong> <?php echo ucfirst($status); ?> | <strong>Date:</strong> <?php echo $date; ?></p>
                <ul>
                    <?php while ($item = $items->fetch_assoc()): ?>
                        <li><?php echo $item['title']; ?> - Qty: <?php echo $item['quantity']; ?> - ₹<?php echo $item['price']; ?></li>
                    <?php endwhile; ?>
                </ul>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
</main>

<style>
.container {
    max-width: 800px;
    margin: auto;
    padding: 30px;
}
.order-card {
    border: 1px solid #ccc;
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 8px;
    background: #f9f9f9;
}
.order-card h3 {
    margin: 0 0 10px;
    color: #2c3e50;
}
.order-card ul {
    list-style: none;
    padding-left: 0;
}
.order-card li {
    padding: 5px 0;
    border-bottom: 1px dashed #ccc;
}
</style>

<?php include('../includes/footer.php'); ?>
