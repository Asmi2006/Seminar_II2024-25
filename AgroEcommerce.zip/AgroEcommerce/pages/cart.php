<?php
session_start();
//  include('../includes/header.php'); 
include('../includes/db.php');
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    echo "<p>Please <a href='login.php'>login as a buyer</a> to view your cart.</p>";
    include('../includes/footer.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle remove
if (isset($_GET['remove'])) {
    $remove_id = intval($_GET['remove']);
    $conn->query("DELETE FROM cart WHERE id = $remove_id AND user_id = $user_id");
    header("Location: cart.php");
    exit();
}

// Handle update quantities
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['quantities'] as $cart_id => $qty) {
        $cart_id = intval($cart_id);
        $qty = intval($qty);
        $conn->query("UPDATE cart SET quantity = $qty WHERE id = $cart_id AND user_id = $user_id");
    }
    header("Location: cart.php");
    exit();
}

// Fetch cart items
$sql = "SELECT c.id as cart_id, p.id as product_id, p.title, p.price, p.image, c.quantity
        FROM cart c
        JOIN products p ON c.product_id = p.id
        WHERE c.user_id = $user_id";

$result = $conn->query($sql);

$total = 0;
include('../includes/header.php');
?>

<main class="container">
    <h2>Your Cart</h2>
    <?php if ($result->num_rows == 0): ?>
        <p>Your cart is empty.</p>
    <?php else: ?>
    <form method="POST">
        <table>
            <tr>
                <th>Product</th>
                <th>Image</th>
                <th>Kg</th>
                <th>Price</th>
                <th>Remove</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): 
                $subtotal = $row['price'] * $row['quantity'];
                $total += $subtotal;
            ?>
            <tr>
                <td><a href="product_detail.php?id=<?php echo $row['product_id']; ?>">
                    <?php echo htmlspecialchars($row['title']); ?></a>
                </td>
                <td><img src="/AgroEcommerce/uploads/<?php echo $row['image']; ?>" width="80"></td>
                <td>
                    <input type="number" name="quantities[<?php echo $row['cart_id']; ?>]" value="<?php echo $row['quantity']; ?>" min="1">
                </td>
                <td>₹<?php echo number_format($subtotal, 2); ?></td>
                <td><a href="?remove=<?php echo $row['cart_id']; ?>" onclick="return confirm('Remove this item?')">🗑️</a></td>
            </tr>
            <?php endwhile; ?>
        </table>

        <div class="cart-summary">
            <p><strong>Total:</strong> ₹<?php echo number_format($total, 2); ?></p>
            <button type="submit">Update Quantities</button>
            <a href="checkout.php" class="checkout-btn">Proceed to Checkout</a>
        </div>
    </form>
    <?php endif; ?>
</main>

<!-- Keep everything same up to this point -->

<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f9f9f9;
    margin: 0;
    padding: 0;
}

.container {
  
    margin: 10px;
    padding: 30px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
    border-radius: 8px;
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #2c3e50;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    background: #fff;
}

th {
    background-color: #4CAF50;
    color: white;
    padding: 12px;
    font-size: 16px;
}

td {
    padding: 12px;
    border: 1px solid #ddd;
    vertical-align: middle;
}

td img {
    max-width: 80px;
    border-radius: 6px;
}

input[type="number"] {
    width: 60px;
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
    text-align: center;
}

a {
    text-decoration: none;
    color: #e74c3c;
    font-weight: bold;
}

a:hover {
    text-decoration: underline;
}

.cart-summary {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 10px;
    border-top: 1px solid #ccc;
}

.cart-summary p {
    font-size: 18px;
    font-weight: bold;
    color: #2c3e50;
}

button[type="submit"],
.checkout-btn {
    background: #28a745;
    color: white;
    padding: 10px 20px;
    font-weight: bold;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: background 0.3s;
}

button[type="submit"]:hover,
.checkout-btn:hover {
    background: #218838;
}

.checkout-btn {
    text-decoration: none;
}

@media (max-width: 768px) {
    table, thead, tbody, th, td, tr {
        display: block;
    }

    th {
        display: none;
    }

    td {
        position: relative;
        padding-left: 50%;
        border: none;
        border-bottom: 1px solid #ccc;
    }

    td::before {
        position: absolute;
        top: 12px;
        left: 12px;
        width: 45%;
        white-space: nowrap;
        font-weight: bold;
        color: #333;
    }

    td:nth-child(1)::before { content: "Product"; }
    td:nth-child(2)::before { content: "Image"; }
    td:nth-child(3)::before { content: "Kg"; }
    td:nth-child(4)::before { content: "Price"; }
    td:nth-child(5)::before { content: "Remove"; }

    .cart-summary {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
}
</style>

<?php include('../includes/footer.php'); ?>

