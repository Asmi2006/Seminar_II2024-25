<?php include('../includes/header.php'); ?>
<main class="container">
    <h2>Product Certification</h2>
    <p>In India, agricultural product certification ensures food quality, safety, and traceability. Here's how farmers and sellers can get certified:</p>
    <ul>
        <li><strong>Organic Certification:</strong> Apply through PGS-India or NPOP. Submit documentation, undergo inspections, and comply with organic standards.</li>
        <li><strong>FSSAI License:</strong> Mandatory for food products. Apply on <a href="https://foscos.fssai.gov.in">FSSAI Portal</a>.</li>
        <li><strong>AGMARK Certification:</strong> Quality mark by the Directorate of Marketing and Inspection. Involves sample testing and inspection.</li>
    </ul>
    <p>Certification helps build trust, improves market access, and ensures consumer satisfaction.</p>
</main>

<style>
.container {
    max-width: 900px;
    margin: auto;
    padding: 20px;
    font-family: Arial, sans-serif;
}
ul li {
    margin-bottom: 10px;
}
</style>
<?php include('../includes/footer.php'); ?>
