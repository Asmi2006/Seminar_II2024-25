<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = htmlspecialchars($_POST['name']);
    $email   = htmlspecialchars($_POST['email']);
    $subject = htmlspecialchars($_POST['subject']);
    $message = htmlspecialchars($_POST['message']);

    // You can later use PHPMailer here
    // For now, let's just simulate
    echo "<p>✅ Thank you, $name! Your message has been received.</p>";
    echo "<p><strong>Subject:</strong> $subject</p>";
    echo "<p><strong>Message:</strong><br>$message</p>";
    echo "<p><a href='contact.php'>Go Back</a></p>";
} else {
    header("Location: contact.php");
    exit();
}
?>
