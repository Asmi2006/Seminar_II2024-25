<?php
include('../includes/header.php');
?>

<main class="contact-container">
    <h2>📞 Contact Us</h2>
    <p>We’d love to hear from you! Whether you have a question about our products, orders, or anything else, our team is ready to help.</p>

    <form method="POST" action="contact_submit.php" class="contact-form">
        <label for="name">Name *</label>
        <input type="text" name="name" required placeholder="Your Name">

        <label for="email">Email *</label>
        <input type="email" name="email" required placeholder="you@example.com">

        <label for="subject">Subject *</label>
        <input type="text" name="subject" required placeholder="Subject">

        <label for="message">Message *</label>
        <textarea name="message" rows="5" required placeholder="Your message here..."></textarea>

        <button type="submit">Send Message</button>
    </form>
</main>

<style>
.contact-container {
    max-width: 600px;
    margin: auto;
    padding: 30px;
    font-family: Arial, sans-serif;
}
.contact-form {
    display: flex;
    flex-direction: column;
}
.contact-form label {
    margin-top: 15px;
    font-weight: bold;
}
.contact-form input, 
.contact-form textarea {
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    margin-top: 5px;
}
.contact-form button {
    margin-top: 20px;
    padding: 12px;
    background: #28a745;
    color: white;
    border: none;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
}
.contact-form button:hover {
    background: #218838;
}
</style>

<?php include('../includes/footer.php'); ?>
