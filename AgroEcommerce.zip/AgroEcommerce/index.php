<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';
?>

<main>
    <section class="hero">
        <h1>Welcome to Agro E-Commerce</h1>
        <p>Buy and Sell Fresh Agro Products</p>
        <a href="register.php" class="btn">Get Started</a>
    </section>

    <section class="features">
        <div class="feature">
            <h3>Farm Fresh</h3>
            <p>Direct from farmers</p>
        </div>
        <div class="feature">
            <h3>Current Market Rates</h3>
            <p><a href="mandi_rates.php">Check now</a></p>
        </div>
        <div class="feature">
            <h3>Secure Orders</h3>
            <p>100% safe delivery</p>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
